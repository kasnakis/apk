package com.ppc.smartsafetyzones.models

data class UserProfile(
    val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    val siteId: String = "",
    val active: Boolean = true,
    val roles: Map<String, Boolean> = emptyMap(),
    val teams: Map<String, Boolean> = emptyMap()
)
