package com.ppc.smartsafetyzones.models

data class ProximityEvent(
    val id: String = "",
    val siteId: String = "",
    val userId: String = "",
    val userEmail: String = "",
    val beaconId: String = "",
    val zoneId: String = "",
    val ruleId: String = "",
    val rssi: Int = 0,
    val severity: String = "",
    val messageTitle: String = "",
    val messageBody: String = "",
    val createdAt: Long = 0L,
    val source: String = "ANDROID_APP",
    val synced: Boolean = true
)
