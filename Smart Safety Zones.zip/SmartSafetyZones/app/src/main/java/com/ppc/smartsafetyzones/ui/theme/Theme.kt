package com.ppc.smartsafetyzones.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable

@Composable
fun SmartSafetyZonesTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(content = content)
}
