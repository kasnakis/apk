package com.ppc.smartsafetyzones.models

data class SszAppSettings(
    val enabled: Boolean = true,
    val defaultScanMode: String = "BALANCED",
    val defaultCooldownSeconds: Int = 300,
    val defaultMinimumDetectionSeconds: Int = 3,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val offlineQueueEnabled: Boolean = true,
    val schemaVersion: Int = 1
)
