package com.ppc.smartsafetyzones.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.ppc.smartsafetyzones.R

class NotificationHelper(
    private val context: Context
) {
    companion object {
        const val HAZARD_CHANNEL_ID = "ssz_hazard_alerts"
        const val HAZARD_CHANNEL_NAME = "Smart Safety Zones Alerts"
    }

    fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                HAZARD_CHANNEL_ID,
                HAZARD_CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Ειδοποιήσεις επικίνδυνων ζωνών Smart Safety Zones"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 250, 500)

                val soundUri: Uri = android.provider.Settings.System.DEFAULT_NOTIFICATION_URI
                val attributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                setSound(soundUri, attributes)
            }

            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    fun showHazardAlert(
        notificationId: Int,
        title: String,
        message: String,
        soundEnabled: Boolean,
        vibrationEnabled: Boolean
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED

            if (!granted) return
        }

        val builder = NotificationCompat.Builder(context, HAZARD_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        if (vibrationEnabled) {
            builder.setVibrate(longArrayOf(0, 500, 250, 500))
        }

        if (!soundEnabled) {
            builder.setSilent(true)
        }

        NotificationManagerCompat.from(context).notify(notificationId, builder.build())
    }
}
