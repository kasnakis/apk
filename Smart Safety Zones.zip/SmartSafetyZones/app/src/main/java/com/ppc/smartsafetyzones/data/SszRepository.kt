package com.ppc.smartsafetyzones.data

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.FirebaseDatabase
import com.ppc.smartsafetyzones.models.ProximityEvent
import com.ppc.smartsafetyzones.models.SszAppSettings
import com.ppc.smartsafetyzones.models.SszBeacon
import com.ppc.smartsafetyzones.models.SszRule
import com.ppc.smartsafetyzones.models.SszZone
import com.ppc.smartsafetyzones.models.UserProfile
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

class SszRepository(
    private val database: FirebaseDatabase = FirebaseDatabase.getInstance()
) {
    suspend fun loadUserProfile(uid: String): UserProfile {
        val snapshot = readOnce("users/$uid")

        if (!snapshot.exists()) {
            throw IllegalStateException("Δεν βρέθηκε προφίλ χρήστη στη βάση: users/$uid")
        }

        val email = snapshot.child("email").asString()
        val displayName = snapshot.child("displayName").asString()
            .ifBlank { snapshot.child("name").asString() }
            .ifBlank { email }

        val siteId = snapshot.child("siteId").asString()
            .ifBlank { snapshot.child("primarySiteId").asString() }
            .ifBlank { snapshot.child("site").asString() }

        if (siteId.isBlank()) {
            throw IllegalStateException("Ο χρήστης δεν έχει siteId / primarySiteId.")
        }

        return UserProfile(
            uid = uid,
            email = email,
            displayName = displayName,
            siteId = siteId,
            active = snapshot.child("active").asBoolean(defaultValue = true),
            roles = snapshot.child("roles").asBooleanMap(),
            teams = snapshot.child("teams").asBooleanMap()
        )
    }

    suspend fun loadAppSettings(): SszAppSettings {
        val snapshot = readOnce("SSZ_appSettings")

        if (!snapshot.exists()) {
            return SszAppSettings()
        }

        return SszAppSettings(
            enabled = snapshot.child("enabled").asBoolean(true),
            defaultScanMode = snapshot.child("defaultScanMode").asString("BALANCED"),
            defaultCooldownSeconds = snapshot.child("defaultCooldownSeconds").asInt(300),
            defaultMinimumDetectionSeconds = snapshot.child("defaultMinimumDetectionSeconds").asInt(3),
            soundEnabled = snapshot.child("soundEnabled").asBoolean(true),
            vibrationEnabled = snapshot.child("vibrationEnabled").asBoolean(true),
            offlineQueueEnabled = snapshot.child("offlineQueueEnabled").asBoolean(true),
            schemaVersion = snapshot.child("schemaVersion").asInt(1)
        )
    }

    suspend fun loadBeacons(siteId: String): List<SszBeacon> {
        val snapshot = readOnce("SSZ_beacons/$siteId")
        return snapshot.children.mapNotNull { child ->
            val id = child.child("id").asString().ifBlank { child.key.orEmpty() }
            if (id.isBlank()) return@mapNotNull null

            SszBeacon(
                id = id,
                siteId = child.child("siteId").asString(siteId),
                name = child.child("name").asString(),
                description = child.child("description").asString(),
                macAddress = child.child("macAddress").asString(),
                uuid = child.child("uuid").asString(),
                major = child.child("major").asInt(0),
                minor = child.child("minor").asInt(0),
                latitude = child.child("latitude").asDouble(0.0),
                longitude = child.child("longitude").asDouble(0.0),
                building = child.child("building").asString(),
                floor = child.child("floor").asString(),
                locationNotes = child.child("locationNotes").asString(),
                zoneId = child.child("zoneId").asString(),
                active = child.child("active").asBoolean(true),
                status = child.child("status").asString("ACTIVE")
            )
        }.filter { it.active && it.status == "ACTIVE" }
    }

    suspend fun loadZones(siteId: String): List<SszZone> {
        val snapshot = readOnce("SSZ_zones/$siteId")
        return snapshot.children.mapNotNull { child ->
            val id = child.child("id").asString().ifBlank { child.key.orEmpty() }
            if (id.isBlank()) return@mapNotNull null

            SszZone(
                id = id,
                siteId = child.child("siteId").asString(siteId),
                title = child.child("title").asString(),
                description = child.child("description").asString(),
                hazardType = child.child("hazardType").asString(),
                severity = child.child("severity").asString("MEDIUM"),
                messageTitle = child.child("messageTitle").asString(),
                messageBody = child.child("messageBody").asString(),
                requiredPpe = child.child("requiredPpe").asBooleanMap(),
                active = child.child("active").asBoolean(true)
            )
        }.filter { it.active }
    }

    suspend fun loadRules(siteId: String): List<SszRule> {
        val snapshot = readOnce("SSZ_rules/$siteId")
        return snapshot.children.mapNotNull { child ->
            val id = child.child("id").asString().ifBlank { child.key.orEmpty() }
            if (id.isBlank()) return@mapNotNull null

            SszRule(
                id = id,
                siteId = child.child("siteId").asString(siteId),
                beaconId = child.child("beaconId").asString(),
                zoneId = child.child("zoneId").asString(),
                triggerType = child.child("triggerType").asString("BLE_PROXIMITY"),
                rssiThreshold = child.child("rssiThreshold").asInt(-75),
                minimumDetectionSeconds = child.child("minimumDetectionSeconds").asInt(3),
                cooldownSeconds = child.child("cooldownSeconds").asInt(300),
                soundEnabled = child.child("soundEnabled").asBoolean(true),
                vibrationEnabled = child.child("vibrationEnabled").asBoolean(true),
                requiresAcknowledgement = child.child("requiresAcknowledgement").asBoolean(true),
                logEvent = child.child("logEvent").asBoolean(true),
                active = child.child("active").asBoolean(true)
            )
        }.filter { it.active }
    }

    suspend fun writeProximityEvent(event: ProximityEvent): String {
        val siteId = event.siteId.ifBlank {
            throw IllegalArgumentException("Missing siteId for SSZ proximity event.")
        }

        val ref = database.reference
            .child("SSZ_proximityEvents")
            .child(siteId)
            .push()

        val eventId = ref.key ?: throw IllegalStateException("Δεν δημιουργήθηκε event id.")

        val payload = mapOf(
            "id" to eventId,
            "siteId" to event.siteId,
            "userId" to event.userId,
            "userEmail" to event.userEmail,
            "beaconId" to event.beaconId,
            "zoneId" to event.zoneId,
            "ruleId" to event.ruleId,
            "rssi" to event.rssi,
            "severity" to event.severity,
            "messageTitle" to event.messageTitle,
            "messageBody" to event.messageBody,
            "createdAt" to event.createdAt,
            "source" to event.source,
            "synced" to true
        )

        return suspendCoroutine { continuation ->
            ref.setValue(payload)
                .addOnSuccessListener { continuation.resume(eventId) }
                .addOnFailureListener { continuation.resumeWithException(it) }
        }
    }

    private suspend fun readOnce(path: String): DataSnapshot {
        return suspendCoroutine { continuation ->
            database.reference.child(path).get()
                .addOnSuccessListener { snapshot -> continuation.resume(snapshot) }
                .addOnFailureListener { error -> continuation.resumeWithException(error) }
        }
    }
}

private fun DataSnapshot.asString(defaultValue: String = ""): String {
    return value?.toString() ?: defaultValue
}

private fun DataSnapshot.asBoolean(defaultValue: Boolean = false): Boolean {
    return when (val raw = value) {
        is Boolean -> raw
        is String -> raw.equals("true", ignoreCase = true)
        is Number -> raw.toInt() != 0
        else -> defaultValue
    }
}

private fun DataSnapshot.asInt(defaultValue: Int = 0): Int {
    return when (val raw = value) {
        is Int -> raw
        is Long -> raw.toInt()
        is Double -> raw.toInt()
        is Float -> raw.toInt()
        is Number -> raw.toInt()
        is String -> raw.toIntOrNull() ?: defaultValue
        else -> defaultValue
    }
}

private fun DataSnapshot.asDouble(defaultValue: Double = 0.0): Double {
    return when (val raw = value) {
        is Double -> raw
        is Float -> raw.toDouble()
        is Long -> raw.toDouble()
        is Int -> raw.toDouble()
        is Number -> raw.toDouble()
        is String -> raw.toDoubleOrNull() ?: defaultValue
        else -> defaultValue
    }
}

private fun DataSnapshot.asBooleanMap(): Map<String, Boolean> {
    return children.associateNotNull { child ->
        val key = child.key ?: return@associateNotNull null
        key to child.asBoolean(false)
    }
}

private inline fun <T, R> Iterable<T>.associateNotNull(transform: (T) -> Pair<String, R>?): Map<String, R> {
    val destination = LinkedHashMap<String, R>()
    for (item in this) {
        val pair = transform(item)
        if (pair != null) {
            destination[pair.first] = pair.second
        }
    }
    return destination
}
