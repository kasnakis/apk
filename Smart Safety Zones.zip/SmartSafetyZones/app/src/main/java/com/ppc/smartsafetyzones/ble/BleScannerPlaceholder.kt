package com.ppc.smartsafetyzones.ble

/**
 * Placeholder for Milestone 2.
 *
 * Milestone 1 deliberately does not start BLE scanning yet.
 * Next step:
 * - Foreground service
 * - Runtime permissions
 * - Site-aware filtering of SSZ_beacons/{siteId}
 * - Local notifications with sound/vibration
 * - RTDB write to SSZ_proximityEvents/{siteId}/{eventId}
 */
class BleScannerPlaceholder
