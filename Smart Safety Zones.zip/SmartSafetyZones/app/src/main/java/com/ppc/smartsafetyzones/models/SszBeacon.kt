package com.ppc.smartsafetyzones.models

data class SszBeacon(
    val id: String = "",
    val siteId: String = "",
    val name: String = "",
    val description: String = "",
    val macAddress: String = "",
    val uuid: String = "",
    val major: Int = 0,
    val minor: Int = 0,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val building: String = "",
    val floor: String = "",
    val locationNotes: String = "",
    val zoneId: String = "",
    val active: Boolean = true,
    val status: String = "ACTIVE"
)
