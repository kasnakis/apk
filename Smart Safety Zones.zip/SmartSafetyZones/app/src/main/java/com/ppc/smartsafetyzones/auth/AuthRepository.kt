package com.ppc.smartsafetyzones.auth

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

/**
 * Authentication boundary for Smart Safety Zones.
 *
 * Current implementation: Firebase Email/Password, same as Sentinel-Ops pilot.
 * Future production implementation: replace internals with Microsoft Entra / SSO / Intune flow
 * without changing the UI and repository consumers.
 */
class AuthRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    fun currentUser(): FirebaseUser? = auth.currentUser

    suspend fun signInWithEmailPassword(email: String, password: String): FirebaseUser {
        return suspendCoroutine { continuation ->
            auth.signInWithEmailAndPassword(email.trim(), password)
                .addOnSuccessListener { result ->
                    val user = result.user
                    if (user != null) {
                        continuation.resume(user)
                    } else {
                        continuation.resumeWithException(
                            IllegalStateException("Δεν βρέθηκε χρήστης μετά τη σύνδεση.")
                        )
                    }
                }
                .addOnFailureListener { error ->
                    continuation.resumeWithException(error)
                }
        }
    }

    fun signOut() {
        auth.signOut()
    }
}
