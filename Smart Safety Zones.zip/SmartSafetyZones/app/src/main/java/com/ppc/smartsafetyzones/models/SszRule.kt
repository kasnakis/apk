package com.ppc.smartsafetyzones.models

data class SszRule(
    val id: String = "",
    val siteId: String = "",
    val beaconId: String = "",
    val zoneId: String = "",
    val triggerType: String = "BLE_PROXIMITY",
    val rssiThreshold: Int = -75,
    val minimumDetectionSeconds: Int = 3,
    val cooldownSeconds: Int = 300,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val requiresAcknowledgement: Boolean = true,
    val logEvent: Boolean = true,
    val active: Boolean = true
)
