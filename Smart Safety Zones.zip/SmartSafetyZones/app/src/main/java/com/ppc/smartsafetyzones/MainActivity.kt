package com.ppc.smartsafetyzones

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.ppc.smartsafetyzones.auth.AuthRepository
import com.ppc.smartsafetyzones.data.SszRepository
import com.ppc.smartsafetyzones.models.SszAppSettings
import com.ppc.smartsafetyzones.models.SszBeacon
import com.ppc.smartsafetyzones.models.SszRule
import com.ppc.smartsafetyzones.models.SszZone
import com.ppc.smartsafetyzones.models.UserProfile
import com.ppc.smartsafetyzones.notifications.NotificationHelper
import com.ppc.smartsafetyzones.ui.theme.SmartSafetyZonesTheme
import kotlinx.coroutines.launch

private enum class ScreenState {
    LOADING,
    LOGIN,
    HOME,
    ERROR
}

private data class HomeData(
    val userProfile: UserProfile,
    val settings: SszAppSettings,
    val beacons: List<SszBeacon>,
    val zones: List<SszZone>,
    val rules: List<SszRule>
)

class MainActivity : ComponentActivity() {

    private val authRepository = AuthRepository()
    private val sszRepository = SszRepository()

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        // Permission result is handled later when showing notifications.
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        NotificationHelper(this).createChannels()
        requestNotificationPermissionIfNeeded()

        setContent {
            SmartSafetyZonesTheme {
                SmartSafetyZonesApp(
                    authRepository = authRepository,
                    sszRepository = sszRepository
                )
            }
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}

@Composable
private fun SmartSafetyZonesApp(
    authRepository: AuthRepository,
    sszRepository: SszRepository
) {
    var screenState by remember { mutableStateOf(ScreenState.LOADING) }
    var errorMessage by remember { mutableStateOf("") }
    var homeData by remember { mutableStateOf<HomeData?>(null) }

    suspend fun loadHomeData() {
        val user = authRepository.currentUser()
            ?: throw IllegalStateException("Δεν υπάρχει συνδεδεμένος χρήστης.")

        val profile = sszRepository.loadUserProfile(user.uid)
        val settings = sszRepository.loadAppSettings()
        val beacons = sszRepository.loadBeacons(profile.siteId)
        val zones = sszRepository.loadZones(profile.siteId)
        val rules = sszRepository.loadRules(profile.siteId)

        homeData = HomeData(
            userProfile = profile,
            settings = settings,
            beacons = beacons,
            zones = zones,
            rules = rules
        )
    }

    LaunchedEffect(Unit) {
        try {
            if (authRepository.currentUser() == null) {
                screenState = ScreenState.LOGIN
            } else {
                loadHomeData()
                screenState = ScreenState.HOME
            }
        } catch (error: Exception) {
            errorMessage = error.message ?: "Άγνωστο σφάλμα."
            screenState = ScreenState.ERROR
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        when (screenState) {
            ScreenState.LOADING -> LoadingScreen(
                modifier = Modifier.padding(innerPadding)
            )

            ScreenState.LOGIN -> LoginScreen(
                modifier = Modifier.padding(innerPadding),
                onLogin = { email, password, onDone ->
                    try {
                        authRepository.signInWithEmailPassword(email, password)
                        loadHomeData()
                        screenState = ScreenState.HOME
                    } catch (error: Exception) {
                        onDone(error.message ?: "Αποτυχία σύνδεσης.")
                    }
                }
            )

            ScreenState.HOME -> {
                val data = homeData
                if (data == null) {
                    LoadingScreen(modifier = Modifier.padding(innerPadding))
                } else {
                    HomeScreen(
                        modifier = Modifier.padding(innerPadding),
                        data = data,
                        onRefresh = {
                            try {
                                screenState = ScreenState.LOADING
                                loadHomeData()
                                screenState = ScreenState.HOME
                            } catch (error: Exception) {
                                errorMessage = error.message ?: "Αποτυχία ανανέωσης."
                                screenState = ScreenState.ERROR
                            }
                        },
                        onSignOut = {
                            authRepository.signOut()
                            homeData = null
                            screenState = ScreenState.LOGIN
                        }
                    )
                }
            }

            ScreenState.ERROR -> ErrorScreen(
                modifier = Modifier.padding(innerPadding),
                message = errorMessage,
                onBackToLogin = {
                    authRepository.signOut()
                    homeData = null
                    errorMessage = ""
                    screenState = ScreenState.LOGIN
                }
            )
        }
    }
}

@Composable
private fun LoadingScreen(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularProgressIndicator()
        Spacer(modifier = Modifier.height(16.dp))
        Text(text = "Φόρτωση Smart Safety Zones...")
    }
}

@Composable
private fun LoginScreen(
    modifier: Modifier = Modifier,
    onLogin: suspend (email: String, password: String, onDone: (String) -> Unit) -> Unit
) {
    val scope = rememberCoroutineScope()

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Smart Safety Zones",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Σύνδεση με λογαριασμό Sentinel-Ops",
            style = MaterialTheme.typography.bodyMedium
        )

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = email,
            onValueChange = {
                email = it
                errorMessage = ""
            },
            label = { Text("Email") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = password,
            onValueChange = {
                password = it
                errorMessage = ""
            },
            label = { Text("Κωδικός") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation()
        )

        if (errorMessage.isNotBlank()) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = errorMessage,
                color = MaterialTheme.colorScheme.error
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            modifier = Modifier.fillMaxWidth(),
            enabled = !loading && email.isNotBlank() && password.isNotBlank(),
            onClick = {
                loading = true
                errorMessage = ""

                scope.launch {
                    onLogin(email, password) { message ->
                        errorMessage = message
                        loading = false
                    }
                }
            }
        ) {
            Text(if (loading) "Σύνδεση..." else "Σύνδεση")
        }
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier = Modifier,
    data: HomeData,
    onRefresh: suspend () -> Unit,
    onSignOut: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var refreshing by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text(
            text = "Smart Safety Zones",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = "Έκδοση 0.1.0 - Milestone 1",
            style = MaterialTheme.typography.bodySmall
        )

        Spacer(modifier = Modifier.height(20.dp))

        InfoCard(title = "Χρήστης") {
            InfoLine(label = "Όνομα", value = data.userProfile.displayName)
            InfoLine(label = "Email", value = data.userProfile.email)
            InfoLine(label = "Site", value = data.userProfile.siteId)
            InfoLine(label = "Ενεργός", value = if (data.userProfile.active) "Ναι" else "Όχι")
        }

        Spacer(modifier = Modifier.height(12.dp))

        InfoCard(title = "SSZ Ρυθμίσεις") {
            InfoLine(label = "Ενεργό", value = if (data.settings.enabled) "Ναι" else "Όχι")
            InfoLine(label = "Scan Mode", value = data.settings.defaultScanMode)
            InfoLine(label = "Cooldown", value = "${data.settings.defaultCooldownSeconds} sec")
            InfoLine(label = "Minimum Detection", value = "${data.settings.defaultMinimumDetectionSeconds} sec")

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Ήχος")
                Switch(
                    checked = data.settings.soundEnabled,
                    onCheckedChange = null
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Δόνηση")
                Switch(
                    checked = data.settings.vibrationEnabled,
                    onCheckedChange = null
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        InfoCard(title = "Δεδομένα Site") {
            InfoLine(label = "Beacons", value = data.beacons.size.toString())
            InfoLine(label = "Ζώνες", value = data.zones.size.toString())
            InfoLine(label = "Κανόνες", value = data.rules.size.toString())
        }

        Spacer(modifier = Modifier.height(12.dp))

        InfoCard(title = "Πρώτα Beacons") {
            if (data.beacons.isEmpty()) {
                Text("Δεν βρέθηκαν beacons για το site.")
            } else {
                data.beacons.take(5).forEach { beacon ->
                    Text(
                        text = "• ${beacon.name} (${beacon.status})",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        InfoCard(title = "Επόμενο Milestone") {
            Text("• BLE Foreground Service")
            Text("• Ανίχνευση γνωστών SSZ beacons")
            Text("• Τοπική ειδοποίηση με ήχο και δόνηση")
            Text("• Καταγραφή σε SSZ_proximityEvents/{siteId}")
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            modifier = Modifier.fillMaxWidth(),
            enabled = !refreshing,
            onClick = {
                refreshing = true
                scope.launch {
                    onRefresh()
                    refreshing = false
                }
            }
        ) {
            Text(if (refreshing) "Ανανέωση..." else "Ανανέωση δεδομένων")
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedButton(
            modifier = Modifier.fillMaxWidth(),
            onClick = onSignOut
        ) {
            Text("Αποσύνδεση")
        }
    }
}

@Composable
private fun ErrorScreen(
    modifier: Modifier = Modifier,
    message: String,
    onBackToLogin: () -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Σφάλμα",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.error,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(text = message)

        Spacer(modifier = Modifier.height(24.dp))

        TextButton(onClick = onBackToLogin) {
            Text("Επιστροφή στη σύνδεση")
        }
    }
}

@Composable
private fun InfoCard(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            content()
        }
    }
}

@Composable
private fun InfoLine(
    label: String,
    value: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label)
        Text(
            text = value,
            fontWeight = FontWeight.SemiBold
        )
    }
}
