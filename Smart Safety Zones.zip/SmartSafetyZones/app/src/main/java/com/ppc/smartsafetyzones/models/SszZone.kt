package com.ppc.smartsafetyzones.models

data class SszZone(
    val id: String = "",
    val siteId: String = "",
    val title: String = "",
    val description: String = "",
    val hazardType: String = "",
    val severity: String = "MEDIUM",
    val messageTitle: String = "",
    val messageBody: String = "",
    val requiredPpe: Map<String, Boolean> = emptyMap(),
    val active: Boolean = true
)
